// JS Which needs to add
document.write(	
	'<script src="js/jquery.js"></script>'+	
	'<script src="js/bootstrap.bundle.min.js"></script>'+
	'<script src="js/custom.js"></script>'
	);